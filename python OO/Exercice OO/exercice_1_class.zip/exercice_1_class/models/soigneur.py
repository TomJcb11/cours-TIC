from datetime import date

class Soigneur:
    def __init__(self, nom="", date_naissance=None, experience=0):
        self.nom = nom
        self.date_naissance = date_naissance if date_naissance else date.today()
        self.experience = experience
        self.nombre_animaux_responsable = 0

    def nourrir(self, animal):
        if animal.en_vie and animal.manger(self.nom):
            print(f"{self.nom} nourrit {animal.nom} 🍽️")
        else:
            print(f"L'animal {animal.nom} est mort, il ne peut pas être nourri.")

    def entretenir(self, animal):
        if animal.en_vie:
            animal.bonheur = 100
            print(f"{self.nom} entretient {animal.nom} 💟")
        else:
            print(f"L'animal {animal.nom} est mort, il ne peut pas être entretenu....")
