import random
from models.soigneur import Soigneur

class Elephant:
    def __init__(self, nom="", soigneur=None):
        self.nom = nom
        self.rassasier = 100
        self.bonheur = 100
        self.en_vie = True
        self.soigneur = soigneur if soigneur else Soigneur()

    def manger(self, nom_soigneur):
        if nom_soigneur == self.soigneur.nom:
            self.rassasier = 100
            return True
        else:
            print(f"Le soigneur {nom_soigneur} n'est pas autorisé à nourrir {self.nom}")

    def diminuer_rassasier(self):
        self.rassasier -= random.randint(10, 30)
        if self.rassasier <= 0:
            self.en_vie = False
            self.rassasier = 0
            self.bonheur = 0
            print(f"{self.nom} est mort de faim ☠️")

    def diminuer_bonheur(self):
        self.bonheur -= random.randint(10, 20)
        if self.bonheur <= 0:
            self.bonheur = 0
