from enum import Enum

# class syntax

class Comportement(Enum):

    GENTIL = "Gentil"
    MOYEN = "Moyen"
    MECHANT = "Méchant"